package JPET;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataProvider extends excel_to_arr1 {
	
	basic_testlogin1 test;
	@BeforeClass
	public void get_data()
	{
		get_test_data();
	}
		
		  @Test(dataProvider="login_data")
		  public void logintest(String eid, String pwd, String exp_eid) 
		  {
			  test = new basic_testlogin1();
			  String a_eid = basic_testlogin1.login(eid, pwd);
			  SoftAssert sa = new SoftAssert();
			  sa.assertEquals(a_eid, exp_eid);
			  sa.assertAll();
			  
		  }
 
		  @DataProvider(name="login_data")
		  public String[][] provide_data()
		  {
			return testdata;
		  }
}
