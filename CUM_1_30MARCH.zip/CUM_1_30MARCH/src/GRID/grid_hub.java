package GRID;

import org.testng.annotations.Test;

public class grid_hub {
  @Test
  public void f() {
  }
}
