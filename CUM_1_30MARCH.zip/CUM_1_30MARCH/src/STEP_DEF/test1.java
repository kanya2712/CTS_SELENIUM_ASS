package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	public static WebDriver dr;
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	    System.out.println("Login page is displayed");
	    System.setProperty("webdriver.chrome.driver","chromedriver.exe");
         dr = new ChromeDriver();
        dr.get("http://demowebshop.tricentis.com/login");
	    
	}

	@When("^User enters login data and click ok button$")
	public void user_enters_login_data_and_click_ok_button() throws Throwable { 
	dr.findElement(By.xpath("//input[@class='email']")).sendKeys("trainingservices06@gmail.com");
    dr.findElement(By.xpath("//input[@class='password']")).sendKeys("password");
    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
    
	}

	@Then("^Home page is displayed:$")
	public void home_page_is_displayed() throws Throwable {
	    String a_email = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    SoftAssert sa = new SoftAssert();
	    sa.assertEquals(a_email,"trainingservices06@gmail.com");
	    sa.assertAll();
	}
	
	@When("^User enters INVALID email id,valid password and ok button$")
	public void user_enters_INVALID_email_id_valid_password_and_ok_button() throws Throwable {
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys("trainingservices0gmail.com");
	    dr.findElement(By.xpath("//input[@class='password']")).sendKeys("password");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    
	    
	}

	@Then("^Login page is displayed with err msg -no customer register$")
	public void login_page_is_displayed_with_err_msg_no_customer_register() throws Throwable {
	    String msg = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	    System.out.println(msg);
	    dr.quit();
	    
	}
}

