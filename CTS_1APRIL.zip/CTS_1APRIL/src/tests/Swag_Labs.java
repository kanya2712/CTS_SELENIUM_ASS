package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.Utilities;
import com.excel.util.excel_logindata;

import page.loginpage;
import page.productspage;

public class Swag_Labs extends excel_logindata {
	WebDriver dr;
	loginpage lp;
	productspage hp;
  @Test
  public void title()
  {
	  String actual = lp.title();
	  String expected="Swag Labs";
	  Assert.assertEquals(actual, expected);
	  
	  
  }
  @Test(dataProvider="LOGIN_DATA")
  public void textcheck(String uname,String pwd,String exp)
{
	  lp.do_login(uname, pwd);
	  String actual=hp.check();
	  System.out.println(actual);
	  Assert.assertEquals(actual, exp);
}
  @BeforeClass
  public void launchBrowser1()
  {
	  get_test_data();
	  System.out.println(testdata);
	  //dr=Utilities.launch_browser("chrome","\"https://www.saucedemo.com/\"");
	//  lp=new loginpage(dr);
	//  hp=new productspage(dr);
	  @BeforeMethod
	  public void launch_Browser()
	  {
		  dr=Utilities.launch_browser("chrome","https://www.saucedemo.com/");
		  lp = new loginpage(dr);
		  hp=new productspage(dr);
		  
	  }
	  
  
  @DataProvider(name="LOGIN_DATA")
  
	  public String[][] get_login_data()
	  {
	  return  testdata;
  }
}
