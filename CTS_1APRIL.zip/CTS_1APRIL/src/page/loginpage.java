package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage {
	WebDriver dr1;
	public loginpage(WebDriver dr)
	{
		dr1=dr;
		
	}
	By uname = By.id("user-name");
	By pwd = By.id("password");
	By login_btn = By .xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
	
public void enter_username(String username)
{
	dr1.findElement(uname).sendKeys(username);
}
public void enter_password(String password)
{
	dr1.findElement(pwd).sendKeys(password);
}
public void click_login()
{
	dr1.findElement(login_btn).click();
}
public void do_login(String username,String password)
{
	enter_username(username);
	
	enter_password(password);
	click_login();
}public String title() {

	String actual= dr1.getTitle();

	//System.out.println(actual);

	return actual;

}
}
