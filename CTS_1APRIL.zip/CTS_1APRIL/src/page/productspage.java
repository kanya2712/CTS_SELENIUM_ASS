package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class productspage {
	
	WebDriver dr2;
	public productspage(WebDriver dr)
	{
		dr2=dr;
	}
	public String check()
	{
		String actual=dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
		dr2.close();
		return actual;
	}
}
